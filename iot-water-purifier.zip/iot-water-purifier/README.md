# iot-water-purifier
An app for intelligent iot based water purifier renting system. Which provides water purifier as a service.
